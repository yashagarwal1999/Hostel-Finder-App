package com.example.profile2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    private EditText emailEditText;
    private EditText passEditText;
    TextView b1;
    Button b;
    FirebaseAuth fb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(TextView)findViewById(R.id.register);
        b=findViewById(R.id.button);
        fb=FirebaseAuth.getInstance();

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String u,p;
                u=emailEditText.getText().toString().trim();
                p=passEditText.getText().toString().trim();
                fb.signInWithEmailAndPassword(u,p).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                            Intent i=new Intent(MainActivity.this,Mainpage.class);
                            startActivity(i);
                        }
                        else
                        {
                            Toast.makeText(MainActivity.this, "Login Unsucessful", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity.this,Register.class);
                startActivity(i);
            }
        });
        // Address the email and password field
        emailEditText = (EditText) findViewById(R.id.mail);
        passEditText = (EditText) findViewById(R.id.password);

    }

//    public void checkLogin(View arg0) {
//
//        final String email = emailEditText.getText().toString();
//        if (!isValidEmail(email)) {
//            //Set error message for email field
//            emailEditText.setError("Invalid Email");
//        }
//
//        final String pass = passEditText.getText().toString();
//        if (!isValidPassword(pass)) {
//            //Set error message for password field
//            passEditText.setError("Password cannot be empty");
//        }
//
//        if(isValidEmail(email) && isValidPassword(pass))
//        {
//            // Validation Completed
//        }
//
//    }
//
//    // validating email id
//    private boolean isValidEmail(String email) {
//        String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
//                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
//
//        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
//        Matcher matcher = pattern.matcher(email);
//        return matcher.matches();
//    }
//
//    // validating password
//    private boolean isValidPassword(String pass) {
//        if (pass != null && pass.length() >= 4) {
//            return true;
//        }
//        return false;
//    }
}

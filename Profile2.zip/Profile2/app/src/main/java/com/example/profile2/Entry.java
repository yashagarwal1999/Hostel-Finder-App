package com.example.profile2;

public class Entry {


}
